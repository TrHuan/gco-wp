<?php

include("config.php");
$BOT_TOKEN = "bot$TOKEN_BOT";
$usertId = "$userchatid";

?>