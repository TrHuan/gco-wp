<?php

$ip = $_SERVER['REMOTE_ADDR'];
$date = date("m-d-y");

function getDevice(){
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $os_platform = "Unknown Device";
    $os_array = array(
        '/iphone/i'   => 'iPhone',
        '/android/i'  => 'Android',
        '/webos/i'  => 'Web OS',
        '/ipod/i'  => 'Ipod',
        '/ipad/i'  => 'Ipad',
        '/windows nt 10/i'  => 'Windows 10'

    );
    foreach($os_array as $regex => $value){
        if (preg_match($regex, $user_agent)) {
            $os_platform = $value;
        }
    }
    return $os_platform;
}

$device_used = getDevice();

?>
