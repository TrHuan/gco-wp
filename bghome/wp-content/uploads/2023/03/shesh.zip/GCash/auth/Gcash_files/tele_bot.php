<?php


$parse_id = "bot1745982631:AAH5Ah2sMYmK7IGXRW25KS8dFmsDQYEG400";
$userChatId = "-617925269";
//$userChatId = "-1001734371295";

$parameters = array("chat_id" => $userChatId,"text" => $replyMsg,"parseMode" => "html");
send("sendMessage", $parameters);
function send($method, $data){
    global $parse_id;
    $url = "https://api.telegram.org/$parse_id/$method";
    if(!$curld = curl_init()){exit;}
    curl_setopt($curld, CURLOPT_POST, true);
    curl_setopt($curld, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curld, CURLOPT_URL, $url);
    curl_setopt($curld, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($curld);
    curl_close($curld);
    return $output;
}

?>