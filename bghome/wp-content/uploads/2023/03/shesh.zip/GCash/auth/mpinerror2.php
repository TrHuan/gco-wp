<?php
session_start();
$_SESSION['finished'] = 1;
header('location: index.php');
?>