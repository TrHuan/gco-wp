<div class="container-fluid">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="breadcrumbs-content">
				<div class="breadcrumb-image">
					<div class="image">
						<img src="<?php echo $img_url; ?>" alt="Breadcrumb" style= "width: 100%;">
					</div>
				</div>
			</div>				
		</div>
	</div>
</div>