
<div class="megamenu menu-desktop d-none d-lg-block">
	<div class="content-box">
		<?php get_template_part('templates/addons/megamenu', 'box'); ?>
	</div>
</div>