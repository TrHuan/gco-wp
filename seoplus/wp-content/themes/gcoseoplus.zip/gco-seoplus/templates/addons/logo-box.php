<div class="logo-box">
	<div class="content-box">
		<a href="<?php echo HOME_URI; ?>">
			<img src="<?php echo lth_custom_logo('full', 60, 20); ?>" alt="Logo" width="120" height="46">
		</a>
	</div>
</div>