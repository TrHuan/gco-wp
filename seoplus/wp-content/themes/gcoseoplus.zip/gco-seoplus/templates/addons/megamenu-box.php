
<nav class="nav">
	<?php
        wp_nav_menu(array(
            'menu' => 'Main Menu',
            'theme_location' => 'main_menu',
        ));
    ?> 
</nav>