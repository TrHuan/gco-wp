<div class="like-share-box">
	<div class="fb-like-box">
		<div class="fb-like" data-href="https://developers.facebook.com/docs/plugins/" data-width="" data-layout="button_count" data-action="like" data-size="small" data-share="false"></div>

		<div id="fb-root"></div>
		<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v9.0&appId=897190940472200&autoLogAppEvents=1" nonce="4TlECEJk"></script>
	</div>

	<div class="fb-share-box">
		<div class="fb-share-button" data-href="https://developers.facebook.com/docs/plugins/" data-layout="button_count" data-size="small"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Chia sẻ</a></div>

		<div id="fb-root"></div>
		<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v9.0&appId=897190940472200&autoLogAppEvents=1" nonce="rt2Ge7lx"></script>
	</div>

	<div class="zalo-like-box">
		<div class="zalo-follow-only-button" data-oaid="579745863508352884"></div>
		<script src="https://sp.zalo.me/plugins/sdk.js"></script>
	</div>

	<div class="zalo-share-box">
		<div class="zalo-share-button" data-href="" data-oaid="579745863508352884" data-layout="1" data-color="blue" data-customize=false></div>
		<script src="https://sp.zalo.me/plugins/sdk.js"></script>
	</div>
</div>