<?php

/**
 * GCO Shortcodes.
 */

require get_theme_file_path() . '/inc/shortcodes/buttons.php';
require get_theme_file_path() . '/inc/shortcodes/ux_image.php';
