<?php
// Add custom Theme Functions here

define('GCO_UX_SHORTCODES_PATH', get_template_directory() . '/inc/shortcodes');
define('GCO_UX_BUILDER_PATH', get_template_directory() . '/inc/builder');
define('GCO_UX_ELEMENTS_PATH', get_template_directory() . '/inc/builder/shortcodes');
define('GCO_UX_ELEMENTS_URI', get_template_directory_uri() . '/inc/builder/shortcodes');
define('GCO_CHILD_PATH', get_theme_file_path());
define('GCO_CHILD_URI', get_theme_file_uri());

function gco_ux_builder_template( $path ) {
  ob_start();
  include get_theme_file_path() . '/inc/elements/templates/' . $path;
  return ob_get_clean();
}

function gco_ux_builder_thumbnail( $name ) {
  return get_theme_file_uri() . '/inc/elements/thumbnails/' . $name . '.svg';
}

function gco_ux_builder_template_thumb( $name ) {
  return get_theme_file_uri() . '/inc/elements/templates/thumbs/' . $name . '.jpg';
}


// Add structure
foreach (glob(__DIR__ . "/inc/structure/*.php") as $filename) {
    require_once $filename;
}


// Add structure
foreach (glob(__DIR__ . "/inc/woocommerce/*.php") as $filename) {
    require_once $filename;
}


// Add Shortcodes
foreach (glob(__DIR__ . "/inc/shortcodes/*.php") as $filename) {
    require_once $filename;
}

// Add UX Builder Elements
add_action( 'ux_builder_setup', function () {

  foreach (glob(__DIR__ . "/inc/elements/*.php") as $filename) {
      require_once $filename;
  }

} );

remove_action( 'woocommerce_after_shop_loop_item','woocommerce_template_loop_add_to_cart',10 );
add_action( 'woocommerce_after_shop_loop_item1','woocommerce_template_loop_add_to_cart',10 );


// Cài đặt những plugins cần thiết
require_once(get_theme_file_path() . '/inc/plugins/class-tgm-plugin-activation.php');
require_once(get_theme_file_path() . '/inc/plugins/plugins.php');


/**
 * Add css
 * 
 * @author LTH
 * @since 2020
 */
function lth_theme_styles() {
    wp_enqueue_style('css-gco-bootstrap', GCO_CHILD_URI . '/assets/css/bootstrap.min.css', false, 'all');
    wp_enqueue_style('css-gco-fontawesome', GCO_CHILD_URI . '/assets/css/all.fontawesome.min.css', false, 'all');
    wp_enqueue_style('css-gco-customs', get_theme_file_uri() . '/assets/css/customs.css', false, 'all');

}
add_action('wp_enqueue_scripts', 'lth_theme_styles');

/**
 * Add js
 * 
 * @author LTH
 * @since 2020
 */
function lth_theme_scripts() {  
    //   wp_enqueue_script('js-gco-jquery', GCO_CHILD_URI .'/assets/js/jquery.min.js', false, 'all');
//   wp_enqueue_script('js-gco-slick', GCO_CHILD_URI .'/assets/js/slick.min.js', false, 'all');
  wp_enqueue_script('js-gco-slick', GCO_CHILD_URI .'/assets/js/main.js', false, 'all');
}
add_action('wp_enqueue_scripts', 'lth_theme_scripts', 99);



function lth_sidebar_register() {

    register_sidebar (
        array (
            'name' => __('Main Header'),
            'id'        => 'main_header',
            'before_widget' => '<div class="main-header">',
            'after_widget' => '</div>',
            'before_title' => '<h2 class="title">',
            'after_title' => '</h2>',
        )
    );

    register_sidebar (
        array (
            'name' => __('Main Footer'),
            'id'        => 'main_footer',
            'before_widget' => '<div class="main-footer">',
            'after_widget' => '</div>',
            'before_title' => '<h2 class="title">',
            'after_title' => '</h2>',
        )
    );

}
add_action('widgets_init', 'lth_sidebar_register');

// Làm việc với các fields trong trang checkout của woocommerce
add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields',99 );
function custom_override_checkout_fields( $fields ) { 
    $fields['billing']['billing_phone'] = array(
        'label' => __('Số điện thoại', 'lth'),
        'placeholder' => _x('Số điện thoại', 'placeholder', 'lth'),
        'required' => true,
        'class' => array('form-row-wide'),
        'minlength' => '10',
        'maxlength' => '11',
        'clear' => true
    );

    $fields['billing']['billing_phone']['placeholder'] = 'Số điện thoại';

    $fields['shipping']['shipping_phone'] = array(
        'label' => __('Số điện thoại', 'lth'),
        'placeholder' => _x('Số điện thoại của người nhận', 'placeholder', 'lth'),
        'required' => true,
        'class' => array('form-row-wide'),
        'minlength' => '10',
        'maxlength' => '11',
        'clear' => true
    );

    $fields['shipping']['billing_phone']['placeholder'] = 'Số điện thoại của người nhận';

    return $fields;
}

add_filter('posts_search', 'my_search_is_exact', 20, 2);
function my_search_is_exact($search, $wp_query){

    global $wpdb;

    if(empty($search)) {
        return $search; 
    } else {
    

        $q = $wp_query->query_vars;
        $n = !empty($q['exact']) ? '' : '%';    

        $search = $searchand = '';

        foreach((array)$q['search_terms'] as $term) :

            $term = esc_sql(like_escape($term));

            $search.= "{$searchand}($wpdb->posts.post_title REGEXP '[[:<:]]{$term}[[:>:]]') OR ($wpdb->posts.post_content REGEXP '[[:<:]]{$term}[[:>:]]')";


            $searchand = ' AND ';

        endforeach;

        if(!empty($search)) :
            $search = " AND ({$search}) ";
            if(!is_user_logged_in())
                $search .= " AND ($wpdb->posts.post_password = '') ";
        endif;

        return $search;
    }

}

add_filter( 'woocommerce_product_add_to_cart_text', 'woo_custom_cart_button_text' );    
function woo_custom_cart_button_text() {
    return __( 'Thêm vào giỏ hàng', 'woocommerce' );
}