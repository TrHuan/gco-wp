<?php
/**
 * Test file for Really Simple SSL to check if uploads directory has code execution permissions
 *
 */

echo "RSSSL CODE EXECUTION MARKER";
