<?php

namespace GeminiLabs\SiteReviews\Addon\Woocommerce\Controllers\BlocksApi;

use Automattic\WooCommerce\Blocks\Domain\Services\ExtendRestApi;
use Automattic\WooCommerce\Blocks\Package;
use Automattic\WooCommerce\Blocks\StoreApi\Schemas\ProductReviewSchema as Schema;
use Automattic\WooCommerce\Blocks\StoreApi\Schemas\AbstractSchema;
use Automattic\WooCommerce\Blocks\StoreApi\Schemas\ImageAttachmentSchema;
use GeminiLabs\SiteReviews\Helpers\Arr;
use GeminiLabs\SiteReviews\Review;

class ProductReviewSchema extends AbstractSchema
{
    /**
     * @var string
     */
    const IDENTIFIER = 'product-review';

    /**
     * @var ImageAttachmentSchema
     */
    protected $image_attachment_schema;

    /**
     * @var string
     */
    protected $title = 'product_review';

    /**
     * @param ExtendRestApi $extend
     * @param ImageAttachmentSchema $image_attachment_schema
     */
    public function __construct(ExtendRestApi $extend, ImageAttachmentSchema $image_attachment_schema)
    {
        $this->image_attachment_schema = $image_attachment_schema;
        parent::__construct($extend);
    }

    /**
     * @return array
     */
    public function get_item_response(Review $review)
    {
        $productId = Arr::get($review->assigned_posts, 0);
        $data = [
            'id' => $review->ID,
            'date_created' => wc_rest_prepare_date_response($review->date),
            'formatted_date_created' => mysql2date('F j, Y', $review->date),
            'date_created_gmt' => wc_rest_prepare_date_response($review->date_gmt),
            'product_id' => $productId,
            'product_name' => get_the_title($productId),
            'product_permalink' => get_permalink($productId),
            'product_image' => $this->image_attachment_schema->get_item_response(get_post_thumbnail_id($productId)),
            'reviewer' => $review->author,
            'review' => wpautop($review->content),
            'rating' => $review->rating,
            'verified' => wc_review_is_from_verified_owner($review->isVerified()),
            'reviewer_avatar_urls' => rest_get_avatar_urls($review->email),
        ];
        return $data;
    }

    /**
     * @return array
     */
    public function get_properties()
    {
        $extend = Package::container()->get(ExtendRestApi::class);
        return (new Schema($extend, new ImageAttachmentSchema($extend)))->get_properties();
    }
}
