<?php

namespace GeminiLabs\SiteReviews\Addon\Woocommerce\Controllers;

use GeminiLabs\SiteReviews\Addon\Woocommerce\Application;
use GeminiLabs\SiteReviews\Addon\Woocommerce\Reminder;

class ReminderController
{
    /**
     * @param int $orderId
     * @return void
     * @action woocommerce_order_status_<completed|processing>
     */
    public function createReminder($orderId)
    {
        if (!glsr_get_option('addons.'.Application::SLUG.'.reminders.enabled', false, 'bool')) {
            return; // reminders are disabled
        }
        if (function_exists('wcs_order_contains_renewal') && wcs_order_contains_renewal($orderId)) {
            return; // don't send reminders for renewals
        }
        if (!$order = wc_get_order($orderId)) {
            return; // this is not an order
        }
        if (!$this->isCategoryInOrder($order)) {
            return; // the order does not contain the required category
        }
        if (!$order->get_user() && !glsr_get_option('addons.'.Application::SLUG.'.reminders.guests', false, 'bool')) {
            return; // do not send reminders to guest users
        }
        if (glsr(Application::class)->filterBool('reminder/skip', false, $orderId)) {
            $order->add_order_note(_x('The review reminder was not scheduled due to a custom filter hook.', 'admin-text', 'site-reviews-woocommerce'));
            return;
        }
        $this->scheduleReminder($order);
    }

    /**
     * @return array
     * @filter woocommerce_email_classes
     */
    public function filterEmailClasses(array $emails)
    {
        if (glsr_get_option('addons.'.Application::SLUG.'.reminders.enabled', false, 'bool')) {
            $emails[glsr()->prefix.Reminder::ID] = glsr(Reminder::class);
        }
        return $emails;
    }

    /**
     * @return array
     * @filter woocommerce_settings_api_form_fields_glsr_reminder
     */
    public function filterEmailFields(array $fields)
    {
        unset($fields['enabled']);
        $fields['additional_content']['css'] = 'width:100%; max-width: 800px; height: 200px;';
        return $fields;
    }

    /**
     * @param \WC_Order $order
     * @return bool
     */
    protected function isCategoryInOrder($order)
    {
        if (empty($category = glsr_get_option('addons.'.Application::SLUG.'.reminders.category'))) {
            return true;
        }
        $items = $order->get_items();
        foreach ($items as $itemId => $item) {
            if (!apply_filters('woocommerce_order_item_visible', true, $item)) {
                continue;
            }
            $categories = get_the_terms($item['product_id'], 'product_cat');
            $categories = wp_list_pluck($categories, 'term_id');
            if (in_array($category, $categories)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param \WC_Order $order
     * @return void
     */
    protected function scheduleReminder($order)
    {
        $days = absint(glsr_get_option('addons.'.Application::SLUG.'.reminders.delay'));
        $timestamp = time() + ($days * DAY_IN_SECONDS);
        $hook = 'site-reviews-woocommerce/reminder/trigger';
        $args = ['order' => $order->get_id()];
        $group = Application::ID;
        if (0 !== WC()->queue()->schedule_single($timestamp, $hook, $args, $group)) {
            $this->setReminderMeta($order->get_id());
            $order->add_order_note(sprintf(
                _x('The review reminder was successfully scheduled for %s.', 'admin-text', 'site-reviews-woocommerce'),
                date_i18n('F j, Y g:i a', $timestamp)
            ));
        } else {
            $order->add_order_note(
                _x('The review reminder could not be scheduled.', 'admin-text', 'site-reviews-woocommerce')
            );
        }
        // $email = WC()->mailer()->emails[glsr()->prefix.Reminder::ID];
        // $email->trigger($order->get_id(), $order);
    }

    /**
     * @param int $orderId
     * @return void
     */
    protected function setReminderMeta($orderId)
    {
        $count = get_post_meta($orderId, '_review_reminder_sent', true);
        update_post_meta($orderId, '_review_reminder_sent', $count ? 1 : 0);
    }
}
