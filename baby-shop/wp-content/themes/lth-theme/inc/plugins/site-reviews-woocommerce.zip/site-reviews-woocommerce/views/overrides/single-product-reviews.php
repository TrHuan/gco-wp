<?php defined('WPINC') || die;

do_action('site-reviews-woocommerce/render/product/reviews');
