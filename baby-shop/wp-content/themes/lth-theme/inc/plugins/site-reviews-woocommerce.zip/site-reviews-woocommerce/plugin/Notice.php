<?php
/**
 * @version 2.1
 */

namespace GeminiLabs\SiteReviews\Addon\Woocommerce;

class Notice
{
    /**
     * @var string
     */
    protected $addonId;

    /**
     * @param string $id
     */
    public function __construct($id)
    {
        $this->addonId = $id;
    }

    /**
     * @param string $type
     * @param string|array|\WP_Error $message
     * @return void
     */
    public function add($type, $message, array $args = [])
    {
        if (empty(array_filter([$message, $type]))) {
            return;
        }
        $args['message'] = $message;
        $args['type'] = $type;
        add_settings_error($this->addonId, '', json_encode($this->normalize($args)), $type);
    }

    /**
     * @param string|array|\WP_Error $message
     * @return void
     */
    public function addError($message, array $args = [])
    {
        $this->add('error', $message, $args);
    }

    /**
     * @param string|array|\WP_Error $message
     * @return void
     */
    public function addSuccess($message, array $args = [])
    {
        $this->add('success', $message, $args);
    }

    /**
     * @param string|array|\WP_Error $message
     * @return void
     */
    public function addWarning($message, array $args = [])
    {
        $this->add('warning', $message, $args);
    }

    /**
     * @return string
     */
    public function build()
    {
        if ($notices = $this->get()) {
            return array_reduce($notices, function ($carry, $notice) {
                return $carry.$this->buildNotice(json_decode($notice['message'], true));
            });
        }
        return '';
    }

    /**
     * @return string
     */
    public function buildActivateButton(array $plugin)
    {
        $url = self_admin_url(sprintf('plugins.php?action=activate&plugin=%s&plugin_status=%s&paged=%s&s=%s',
            $plugin['plugin'],
            filter_input(INPUT_GET, 'plugin_status'),
            filter_input(INPUT_GET, 'paged'),
            filter_input(INPUT_GET, 's')
        ));
        $url = wp_nonce_url($url, 'activate-plugin_'.$plugin['plugin']);
        return $this->buildButton($url, _x('Activate', 'notice button (admin-text)', 'site-reviews-woocommerce'), $plugin['name']);
    }

    /**
     * @return string
     */
    public function buildInstallButton(array $plugin)
    {
        $url = self_admin_url(sprintf('update.php?action=install-plugin&plugin=%s', $plugin['slug']));
        $url = wp_nonce_url($url, 'install-plugin_'.$plugin['slug']);
        return $this->buildButton($url, _x('Install', 'notice button (admin-text)', 'site-reviews-woocommerce'), $plugin['name']);
    }

    /**
     * @return string
     */
    public function buildUpdateButton(array $plugin)
    {
        $url = self_admin_url(sprintf('update.php?action=upgrade-plugin&plugin=%s', $plugin['plugin']));
        $url = wp_nonce_url($url, 'upgrade-plugin_'.$plugin['plugin']);
        return $this->buildButton($url, _x('Update', 'notice button (admin-text)', 'site-reviews-woocommerce'), $plugin['name']);
    }

    /**
     * @return array
     */
    public function get()
    {
        $notices = array_map('unserialize',
            array_unique(array_map('serialize', get_settings_errors($this->addonId)))
        );
        usort($notices, function ($a, $b) {
            $order = ['error', 'warning', 'info', 'success'];
            return array_search($a['type'], $order) - array_search($b['type'], $order);
        });
        return $notices;
    }

    /**
     * @return void
     */
    public function render()
    {
        echo $this->build();
    }

    /**
     * @param string $href
     * @param string $action
     * @param string $pluginName
     * @return string
     */
    protected function buildButton($href, $action, $pluginName)
    {
        return sprintf('<a href="%s" class="button button-small">%s %s</a>', $href, $action, $pluginName);
    }

    /**
     * @return string
     */
    protected function buildNotice(array $args)
    {
        $messages = array_reduce($args['messages'], function ($carry, $message) {
            return $carry.wpautop($message);
        });
        $class = 'notice notice-'.$args['type'];
        if ($args['dismissible']) {
            $class .= ' is-dismissible';
        }
        return '<div class="'.$class.'">'.$messages.'</div>';
    }

    /**
     * @return array
     */
    protected function normalize(array $args)
    {
        $defaults = [
            'dismissible' => true,
            'message' => '',
            'type' => '',
        ];
        $args = shortcode_atts($defaults, $args);
        if (!in_array($args['type'], ['error', 'warning', 'success'])) {
            $args['type'] = 'success';
        }
        $args['messages'] = is_wp_error($args['message'])
            ? (array) $args['message']->get_error_message()
            : (array) $args['message'];
        unset($args['message']);
        return $args;
    }
}
