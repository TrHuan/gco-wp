<?php defined('WPINC') || die;

do_action('site-reviews-woocommerce/render/loop/rating');
