<?php
/**
 * ╔═╗╔═╗╔╦╗╦╔╗╔╦  ╦  ╔═╗╔╗ ╔═╗
 * ║ ╦║╣ ║║║║║║║║  ║  ╠═╣╠╩╗╚═╗
 * ╚═╝╚═╝╩ ╩╩╝╚╝╩  ╩═╝╩ ╩╚═╝╚═╝.
 *
 * Plugin Name:       Site Reviews: Woocommerce Reviews
 * Plugin URI:        https://niftyplugins.com/plugins/woocommerce
 * Description:       Integrate Site Reviews with your products
 * Version:           1.3.3
 * Author:            Paul Ryley
 * Author URI:        https://niftyplugins.com
 * License:           GPL2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.5
 * Requires PHP:      5.6.20
 * Tested up to:      5.7
 * Text Domain:       site-reviews-woocommerce
 * Domain Path:       languages
 * WC requires at least: 4.9
 * WC tested up to: 5.0
 */
defined('WPINC') || die;

if (!class_exists('GL_Plugin_Check_v5')) {
    require_once __DIR__.'/activate.php';
}
if (!(new GL_Plugin_Check_v5(__FILE__))->canProceed()) {
    return;
}
require_once __DIR__.'/autoload.php';
add_action('site-reviews/addon/register', function ($app) {
    // Overriding the Woocommerce REST API is currently extremely fragile, 
    // we need to limit Woocommerce compatibilty to v4.9.* as a safety precaution.
    $gatekeeper = new GeminiLabs\SiteReviews\Addon\Woocommerce\Gatekeeper(__FILE__, [
        'site-reviews/site-reviews.php' => 'Site Reviews|5.8|https://wordpress.org/plugins/site-reviews|6.0',
        'woocommerce/woocommerce.php' => 'Woocommerce|4.9|https://wordpress.org/plugins/woocommerce|6.0',
    ]);
    if ($gatekeeper->allows()) {
        $app->register(GeminiLabs\SiteReviews\Addon\Woocommerce\Application::class);
    }
});
