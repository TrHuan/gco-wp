=== Site Reviews: Woocommerce ===
Contributors: pryley, geminilabs
Donate link: https://www.paypal.me/pryley
Tags: Site Reviews, Woocommerce
Tested up to: 5.7
Requires at least: 5.5
Requires PHP: 5.6.20
Stable tag: 1.3.3
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrate Site Reviews with Woocommerce.

== Description ==

= Minimum plugin requirements =

If your server and website does not meet these minimum requirements, the plugin will automatically deactivate and a notice will appear explaining why.

- WordPress 5.5
- PHP 5.6.20

== Installation ==

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.3.3 (2021-04-05) =

- Fixed rating values in the Woocommerce Products widget

= 1.3.2 (2021-03-20) =

- Added setting tooltips

= 1.3.1 (2021-03-18) =

- Fixed translated Woocommerce template strings, they should now inherit the Woocommerce translation strings

= 1.3.0 (2021-02-10) =

- Added support for Woocommerce 5.0
- Fixed the integration with the Woocommerce product review schema
- Fixed the "Filter Products by Rating" widget
- Fixed the `/wc-analytics/products/reviews` REST API routes

= 1.2.2 (2021-01-29) =

- Fixed an internal bug

= 1.2.1 (2021-01-28) =

- Fixed a SQL error

= 1.2.0 (2021-01-25) =

__Note__: The review links in the "Recent Product Reviews" widget do not yet work; this will be addressed with Site Reviews 5.6!

- Added a black star option
- Added a setting to sort reviews on the shop page by the bayesian average rating
- Added integration with the Woocommerce Analytics
- Added integration with the Woocommerce Blocks and Widgets
- Added integration with the Woocommerce REST API
- Fixed an issue preventing the "Enable reviews" product option from syncing in multilingual products
- Fixed an issue which disabled Woocommerce auto-updates

= 1.1.2 (2021-01-12) =

- Updated the "WC tested up to" in the readme to Woocommerce 4.9.0

= 1.1.1 (2021-01-08) =

- Fixed override of `wc_get_template('single-product-reviews.php');`

= 1.1.0 (2021-01-08) =

- Added the `site-reviews-woocommerce/render/loop/rating` action hook which can be used to display the product rating elsewhere in the shop product loop.
- Added the `site-reviews-woocommerce/render/product/reviews` action hook which can be used to display the single-product reviews section elsewhere on the page.
- Fixed the single product reviews template

= 1.0.1 (2021-01-07) =

- Fixed review pagination link styling in some Woocommerce themes
- Fixed the loop rating on the shop page of some Woocommerce themes

= 1.0.0 (2020-12-22) =

- First release
