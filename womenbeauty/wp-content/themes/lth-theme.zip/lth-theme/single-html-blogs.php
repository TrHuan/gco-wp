<?php
/**
 * The template for displaying all single posts
 * 
 * @author LTH (trhuan177@gmail.com)
 * @since 2020
 */
get_header(); ?>

<main class="main main-single-html-blogs">
    <?php the_content(); ?>
</main>

<?php get_footer(); ?> 
