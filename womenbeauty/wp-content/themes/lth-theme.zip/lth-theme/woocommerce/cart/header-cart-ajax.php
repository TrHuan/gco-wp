<div class="carts-content">
	<div class="cart-icon" >
		<div class="cart-btn">
            <a href="<?php echo wc_get_cart_url(); ?>" class="vk-btn vk-btn--violet-1">
                <span class="pe-7s-shopbag"></span>
                <span class="total-pro item-count"><?php echo  $woocommerce->cart->cart_contents_count ?></span>
            </a>
        </div>
	</div>
</div>