<?php
/**
 * Box search
 * 
 * @author LTH 
 * @since 2020
 */
?>

<a href="#">
    <span class="pe-7s-search"></span>
</a>
<div class="categorie-search-box ht-dropdown">
    <form action="#">
        <input type="text" name="search" placeholder="<?php echo __('Tìm kiếm'); ?>">
        <button>
            <span class="pe-7s-search"></span>
        </button>
        <input type="hidden" name="post_type" value="product">
    </form>
</div>