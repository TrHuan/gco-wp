<?php
/**
 * The template for displaying archive pages
 * 
 * @author LTH
 * @since 2020
 */
get_header(); ?>

<main class="main main-html-blogs">
    <?php the_content(); ?>
</main>

<?php get_footer(); ?>
