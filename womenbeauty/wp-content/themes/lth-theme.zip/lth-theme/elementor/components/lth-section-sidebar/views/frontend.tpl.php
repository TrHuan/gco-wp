<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly 
?>

<div class="multi-sec-sidebar pt-90">
   <div class="container">
      <div class="row">
         <div class="col-lg-3 mb-all-40">
            <div class="sidebar">
               <?php 
                  // $fullsidebar = $settings['url_sidebar']['url'];
                  // $explode_fullsidebar = explode('/', $fullsidebar);
                  // $last_sidebar = $explode_fullsidebar[count($explode_fullsidebar) - 2];
                  // $sidebar = get_posts( array( 'post_type' => 'html-blocks', 'name' => $last_sidebar ) );
                  // if( count($sidebar) ) {
                  //    $side = $sidebar[0]->post_content;
                  //    // do whatever you want
                  //    echo $side;
                  // }
               ?>

               <?php
                  $fullsidebar = $settings['url_sidebar']['url'];
                  $explode_fullsidebar = explode('/', $fullsidebar);
                  $last_sidebar = $explode_fullsidebar[count($explode_fullsidebar) - 2];
                   $args = new WP_Query(array(
                       'post_type'      => 'html-blocks',
                      'posts_per_page' => 1,
                      'name'  => $last_sidebar,
                   ));
               ?>

               <?php while ($args->have_posts()) : $args->the_post();
                  the_ID();
                  the_title();
                  the_content();
              endwhile ; wp_reset_query() ; ?>
            </div>
         </div>

         <div class="col-lg-9">
            <div class="sidebar-right-content">
               <?php
                  $fullcontent = $settings['url_content']['url'];
                  $explode_fullcontent = explode('/', $fullcontent);
                  $last_content = $explode_fullcontent[count($explode_fullcontent) - 2];
                   $args = new WP_Query(array(
                       'post_type'      => 'html-blocks',
                      'posts_per_page' => 1,
                      'name'  => $last_content,
                   ));
               ?>

               <?php while ($args->have_posts()) : $args->the_post();
                  $id = get_the_ID();
                  the_title();
                  the_content($id);
               endwhile ; wp_reset_query() ; ?>
            </div>
         </div>
      </div>
   </div>
</div>