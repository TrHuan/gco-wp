<?php
/**
 * The template for displaying all single posts
 * 
 * @author LTH (trhuan177@gmail.com)
 * @since 2020
 */
get_header(); ?>
<?php $ptp = get_post_type();
if ($ptp = 'html-blogs' || $ptp = 'page') { ?>
    <style type="text/css">
        #yoast-introduction,
        header, footer {
            display: none !important;
        }
    </style>
    
    <?php the_content();
} else { ?>
    <main class="main main-page main-single">
        <h1 class="vk-page__title mb-1" ><?php the_title(); ?></h1>
        <div class="vk-blog-detail__date"><?php echo __('Đăng ngày'); ?> <?php the_time('d'); ?>/<?php the_time('m'); ?>/<?php the_time('Y'); ?></div>
        <div class="vk-blog-detail__content">                            
            <?php the_content(); ?>
        </div> <!--./content-->
    </main>
<?php } ?>

<?php get_footer(); ?> 
