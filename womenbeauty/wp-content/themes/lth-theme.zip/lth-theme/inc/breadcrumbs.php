
<div class="breadcrumbs">
	<div class="container-fluid">
		<!-- <div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"> -->
				<?php //require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-image.php'); ?>
			<!-- </div>
		</div> -->


		<?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-content.php'); ?>
	</div>
</div>