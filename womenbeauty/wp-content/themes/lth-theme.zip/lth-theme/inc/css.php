<?php
/**
 * Css
 * @author LTH
 * @since 2020
 */
?>

<?php $color = get_field('color', 'option'); ?>

<style type="text/css">

	.add-to-cart:hover,
	.cart-wishlist:hover::before,
	.cart-compare:hover:before,
	.add-to-cart:hover:before, 
	.pro-title a:hover,
	.single-makal-product .add-to-cart:hover,
	.single-footer li a:hover,
	.single-footer .social-icon li a:hover,
	.footer-list li a:hover,
	.footer-menu li a:hover,
	.footer-copyright p a:hover,
	.header-top-left ul > li:hover > a,
	.header-top-right ul > li:hover > a,
	.wish-compare-items li a:hover,
	.wpcf7-submit, .submit, .btn, .button, button,
	a:hover {
		color: <?php echo $color; ?>;
	}

    .wpcf7-submit:hover, .submit:hover, .btn:hover, .button:hover, button:hover {
		background-color: <?php echo $color; ?>;
		color: #fff;
	}

	/*.back-to-top {
		border-color: <?php echo $color; ?>;
	}*/

	/*.back-to-top,
	.wpcf7-submit, .submit, .btn, .button, button,
	a:hover {
		color: <?php echo $color; ?>;
	}

	.back-to-top:hover,
    .wpcf7-submit:hover, .submit:hover, .btn:hover, .button:hover, button:hover {
		background-color: <?php echo $color; ?>;
		color: #fff;
	}

	.back-to-top {
		border-color: <?php echo $color; ?>;
	}*/

</style>